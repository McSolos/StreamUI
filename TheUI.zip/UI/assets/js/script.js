function showModal(title) {
    document.getElementById('videoModal').style.display = 'block';
    document.getElementById('modalTitle').innerText = title;

    var clickedThumbnail = document.querySelector('.video-thumbnail[data-title="' + title + '"]');
    
    // Get the content from the clicked thumbnail
    var videoTitle = clickedThumbnail.querySelector('h2').innerText;
    var videoDescription = clickedThumbnail.querySelector('p').innerText;

    // Update the modal content with the content from the clicked thumbnail
    document.getElementById('videoModal').style.display = 'block';
    document.getElementById('modalTitle').innerText = videoTitle;
    document.getElementById('modalDescription').innerText = videoDescription;
}

function closeModal() {
    document.getElementById('videoModal').style.display = 'none';
    
}

function toggleNav() {
    const navLinks = document.getElementById('navLinks');
    if (navLinks.classList.contains('show')) {
        navLinks.classList.remove('show');
    } else {
        navLinks.classList.add('show');
    }
}
// scroll buttons
function hello(button) {
    console.log("hello is called");
    const row = button.parentNode.querySelector('.row');
    row.hello -= row.clientWidth / 2;
    row.scrollTo({ left: row.hello, behavior: 'smooth' });
}

function scrollRight(button) {
    console.log("scrollRight is called");
    const row = button.parentNode.querySelector('.row');
    row.hello += row.clientWidth / 2;
    row.scrollTo({ left: row.hello, behavior: 'smooth' });
}

//stream page javascript

function playVideo(url) {
    const playPageUrl = `play.html?videoUrl=${encodeURIComponent(url)}`;
    player.switchURL(url);
  }
  
  
  
  let player;
  
  $(function() {
    // Initialize the HlsJsPlayer with initial settings
    player = new HlsJsPlayer({
      id: "videoPlayer",
      url: 'https://alpha.ipnxnigeria.net/doc/natgeowild.m3u8',
      isLive: true,
      autoplay: true,
      volume: 0.8,
      width: 1024,
      pip: true,
      download: false,
      fitVideoSize: 'auto',
      lang: 'en',
    });
  });
